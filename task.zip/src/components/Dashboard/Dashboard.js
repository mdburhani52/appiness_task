import React from 'react';

import { Link } from 'react-router-dom';
import { ROUTER_PATH } from '../../services/config.js';
import Button from '../../utils/Button/Button';
import ReactTable from 'react-table-v6';
import 'react-table-v6/react-table.css';
import './Dashboard.scss';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import { dashboardData , logOut} from '../../store/actions';
class Dashboard extends React.Component {
    constructor(props) {
        super(props);
        this.state = {


        }
    }


    componentDidMount() {
        // when we ll have actual api
        // this.props.dashboardData();
    }


    logOutHandler = () => {
        this.props.logOut();      
    }


    render() {


        const columns = [

            { Header: 'Name', accessor: 'name',  Cell: (props) => <div>{props.original.name}</div> },
            { Header: 'Age', accessor: 'age', maxWidth: 120, Cell: (props) => <div>{props.original.age + ' Years'}</div> },
            {
                Header: 'Gender', accessor: 'gender', maxWidth: 120, Cell: (props) =>
                    <div>{props.original.gender == 'male' ?
                        <span className={'bg-warning px-1 py-1 color-w'}>Male</span>
                        :
                        <span className={'bg-danger px-1 py-1 color-w'}>Female</span>}
                    </div>

            },
            { Header: 'Email', accessor: 'email', maxWidth: 250, Cell: (props) => <div>{props.original.email}</div> },
            { Header: 'Phone No.', accessor: 'phoneNo', maxWidth: 250, Cell: (props) => <div>{props.original.phoneNo}</div> },
            {
                Header: 'Action',
                maxWidth: 62,
                sortable: false,
                Cell: (props) => <div className="action_c w-100 pr-3 d-flex align-items-center justify-content-end">
                    <i className="fa fa-trash delete_ic"></i>
                </div>
            },
        ]

        

        return (
            <section className={'DashboardSec'}>
                <div className={'container'}>

                    <h3 className={'mt-5 mb-5 col-12 text-center d-flex align-items-center justify-content-center'}>
                        <strong>Dashboard</strong>
                        <Button color={2} value={'Log Out'} click={this.logOutHandler} className={'ml-3'} />
                    </h3>

                    <div className="table_common__ notifyTable w-100 ">
                        <ReactTable
                            data={this.props.data}
                            columns={columns}
                            minRows={1}
                            defaultPageSize={10}
                            loadingText={'loading...'}
                            previousText={<span className="icon fa fa-angle-left previous"></span>}
                            nextText={<span className="icon fa fa-angle-right next"></span>}
                        />
                    </div>




                </div>
            </section>
        );
    }
}



const mapStateToProps = state => {
    return {
        data: state.DashboardReducer.data
    }
}

const mapDispatchToProps = (dispatch) => bindActionCreators({
    dashboardData, logOut
}, dispatch);

export default connect(mapStateToProps, mapDispatchToProps)(Dashboard);