import React from 'react';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import { Row, Col } from 'react-bootstrap';

import './Login.scss';
import Button from '../../utils/Button/Button';

import { Redirect } from 'react-router-dom';
import { loginCheck, login } from '../../store/actions';

import { ROUTER_PATH } from '../../services/config';
class Login extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            errorMessages: {
                email: '',
                password: ''
            },
            email:'',
            password:'',
            serverMessage:null
        }
    }

    inputHandler = e => {
        let state = this.state;
        state[e.target.name] = e.target.value;
        state['errorMessages'][e.target.name] = '';
        this.setState(state);
    }

    submitHandler = e => {
        e.preventDefault();

        let state = this.state;
        let errorMessages = {};

        this.setState({ errorMessages, serverMessage: null });


        var valid = true;
        if (state.email == '') {
            errorMessages['email'] = "Please enter email";
            valid = false;
        }
        if (state.password == '') {
            errorMessages['password'] = "Please enter password";
            valid = false;
        }

        if (state.email !== '') {
            let validateEmail = this.validateEmail(state.email);
            if (!validateEmail) {
                errorMessages['email'] = "Please enter valid email";
                valid = false;
            }
        }

        if (!valid) {
            this.setState({ errorMessages });
        } 
        
        else {
            let serverError = true;
            if (state.email !== this.props.AuthData.email || state.password !== this.props.AuthData.password) {
                this.setState({ serverMessage: { status: false, message: 'Invalid email or password' } })
                return false;
            }
            
            else{
                this.props.login();
                this.setState({ serverMessage: { status: true, message: 'Login successfull' } })
                setTimeout(()=>{this.setState({redirect:true})}, 1000)
            }
        }


    }

    validateEmail = (email) => {
        var re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
        return re.test(String(email).toLowerCase());
    }

    render() {

        if (this.state.redirect) {
            return <Redirect to={ROUTER_PATH + 'dashboard'} />
        }


        return (
            <React.Fragment>
                <section className={'loginSec'}>
                    <div className={'loginBox'}>

                        <h3 className={'text-center'}>LOGIN</h3>

                        <Row className={'mt-4'}>
                            <Col xs={12}>
                                <form onSubmit={this.submitHandler}>


                                    <div className={'form-group'}>
                                        <label>Email</label>
                                        <input
                                            type={'text'}
                                            name={'email'}
                                            value={this.state.email || ''}
                                            className={'form-control'}
                                            onChange={this.inputHandler}
                                        />
                                        {
                                            this.state.errorMessages.email ?
                                                <div className={'error'}>{this.state.errorMessages.email}</div>
                                                : ''
                                        }
                                    </div>
                                    <div className={'form-group'}>
                                        <label>Password</label>
                                        <input
                                            type={'password'}
                                            name={'password'}
                                            value={this.state.password || ''}
                                            className={'form-control'}
                                            onChange={this.inputHandler}
                                        />
                                        {
                                            this.state.errorMessages.password ?
                                                <div className={'error'}>{this.state.errorMessages.password}</div>
                                                : ''
                                        }
                                    </div>
                                    <div className={'form-group'}>
                                        <Button
                                            value={'Login'}
                                            color={1}
                                            className={'w-100'}
                                        // click={this.submitHandler}
                                        />
                                    </div>

                                    {
                                        this.state.serverMessage ?
                                            <div className={'form-group'}>
                                                <div className={`alert text-center alert-${this.state.serverMessage.status ? 'success' : 'danger'}`}>
                                                    {this.state.serverMessage.message}
                                                </div>
                                            </div>
                                            : ''
                                    }

                                </form>
                            </Col>
                        </Row>

                    </div>
                </section>
            </React.Fragment>
        )
    }
}

const mapStateToProps = state => {
    return {
        AuthData: state.AuthReducer.authData
    }
}

const mapDispatchToProps = (dispatch) => bindActionCreators({
    loginCheck, login
}, dispatch);

export default connect(mapStateToProps, mapDispatchToProps)(Login);