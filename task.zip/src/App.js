import React from 'react';

import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';

import {ROUTER_PATH } from './services/config';
import { BrowserRouter as Router, Route, Switch, Redirect } from 'react-router-dom';
import ScrollToTop from 'react-router-scroll-top';

import Login from './components/Login/Login';
import Dashboard from './components/Dashboard/Dashboard';
import {loginCheck} from './store/actions';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';

function App(props) {
  return (
    <div className="App">
      <Router >
        <ScrollToTop>
          <Switch>
             <Route exact path={ROUTER_PATH} render={() => !props.loginCheck()? <Login /> : <Redirect to={ROUTER_PATH + 'dashboard'} /> } />
             <Route exact path={ROUTER_PATH + 'dashboard'} render={() => props.loginCheck()? <Dashboard /> : <Redirect to={ROUTER_PATH} />} />
          </Switch>
        </ScrollToTop>
      </Router>
    </div>
  );
}


const mapStateToProps = state => {
  return { 
  }
}

const mapDispatchToProps = (dispatch) => bindActionCreators({
  loginCheck
}, dispatch);

export default connect(mapStateToProps, mapDispatchToProps)(App);