import React from 'react';


const Button = (props) => {
    let colorClass;
    switch (props.color) {
        case 1:
            colorClass = "btn-warning";
            break;
        case 2:
            colorClass = "btn-danger";
            break;
        default:
            colorClass = "btn-success"
    }

return <button className={`btn ${colorClass} ${props.className}`} onClick={props.click}>{props.value || 'click me'}</button>
}

export default Button;