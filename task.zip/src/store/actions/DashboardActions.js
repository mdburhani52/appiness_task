
import * as actionTypes from "./ActionTypes.js";

export function postData(url, data = {}) {
    var request_data = { 'data': data }
    return dispatch => {
        return new Promise((resolve, reject) => {
            fetch(url, {
                method: 'POST',
                body: JSON.stringify(request_data)
            })
                .then((response) => response.json())
                .then((response) => {
                    resolve(response);
                })
                .catch((error) => {
                    reject(error);
                    // alert(error);
                });
        });

    }
}


export const dashboardData = () => {
    return dispatch => {
        dispatch(postData('api_path/dashboardData.json'))
        .then(res => {
            dispatch(listSave(res))
        })
    }
    function listSave(data) { return { type: actionTypes.LISTDATA, payload: data } }
}