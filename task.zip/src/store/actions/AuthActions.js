


export function setLoginToken() {
    var token = Math.random().toString(36).substr(2);
    return dispatch => {
        localStorage.setItem("appiness_Token", token);
    }
}

export function removeLoginToken() {
    return dispatch => {
        localStorage.removeItem("appiness_Token");
    }
}

export function getLoginToken() {
    return localStorage.getItem("appiness_Token");
}

export const loginCheck = () => {
    return dispatch => {
        // check token with db token when it will be available for double cross .. 
        if (getLoginToken() !== '' && getLoginToken() !== undefined && getLoginToken() !== null) {
            return true;
        } else {
            return false;
        }

    }
}


export const login = () => {
    return dispatch => {
        dispatch( setLoginToken());
        return true;
    }
}

export function logOut() {
    return dispatch => {
        dispatch(removeLoginToken());
        var url= '/'; 
        window.location = url; 
        return true;
    }
}