
import * as actionType from '../actions';

const initialState = {
    authData:{
        email:'hruday@gmail.com',
        password:'hruday123'
    }
}

const reducer = (state = initialState, action) => {
    switch (action.type) {
       
    }
    return state;
}

export default reducer;